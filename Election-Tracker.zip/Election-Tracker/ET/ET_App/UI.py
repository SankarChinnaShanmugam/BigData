import json
import ET_App.views

def getJSON(filepath)
with open(".\example.json", "r") as read_file:
    request = json.load(read_file)






print("abc")
