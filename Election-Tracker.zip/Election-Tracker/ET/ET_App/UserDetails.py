from collections import defaultdict

mf_collection = defaultdict(list)

class OptionValues:
    def __init__(self, OptionName, OptionValue):
        self.OptionName = OptionName
        self.OptionValue = OptionValue

class QuestionDetails:
    def __init__(self, QuestionId, QuestionName, mf_collection):
       self.QuestionID = QuestionID
       self.QuestionName = QuestionName
       self.mf_collection = mf_collection
       

class QuestionValues:

    def __init__(self, QuestionID):
        self.QuestionID = QuestionID
       
    def GetQuestionValues(self):
        print("GetQuestionValues Started")
       
        try:
            connection = psycopg2.connect(user="postgres",
                                          password="postgres",
                                          host="127.0.0.1",
                                          port="5432",
                                          database="ET")

            cursor = connection.cursor()
            getuserquery = """select * from Et_app_user"""
            cur.execute(getuserquery)
            print("Selecting rows from the user table")
            user_records = cur.fetchall()
            print("Print each row and it's columns values")
            for row in user_records:
                #print("UserId = ", row[0], )
                #print("firstName = ", row[1])
                print("lastName = ", row[2], "\n")

            print("Adding Users...")
        except (Exception, psycopg2.DatabaseError) as error:
            print("Error while connecting to PostgreSQL", error)
        finally:
            # closing database connection.
            if (connection):
                cursor.close()
                connection.close()
                print("PostgreSQL connection is closed")

        return QuestionDetails

