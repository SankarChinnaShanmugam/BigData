from django.apps import AppConfig


class EtAppConfig(AppConfig):
    name = 'ET_App'
