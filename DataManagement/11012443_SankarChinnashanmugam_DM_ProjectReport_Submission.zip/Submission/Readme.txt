Goal-A
1.Each tool ouput files, receipe screen shots and applicable  scripts are avaiable individually. 
2.External Data Source reffred in australian weather data set resource files are updated.
3.The original and Final ouput files are updated outside the folders.
4. Running notes on inital analysis are updated in Goal A folder. 

Goal-B
1.Each tool ouput files, receipe screen shots and applicable  scripts are avaiable individually.
2.The original and Final ouput files are updated outside the folders.
3.Running notes on inital analysis are updated in Goal B folder. 

Result PDF Files:
1. 11012443_SankarChinnaShanmugam_ACDM_ProReport_GoalA.pdf
2. 11012443_SankarChinnaShanmugam_ACDM_ProReport_GoalB.pdf 

are the output of project reports. 
 