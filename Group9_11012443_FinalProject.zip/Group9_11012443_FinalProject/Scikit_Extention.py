from sklearn.linear_model import RidgeCV

class Extended(RidgeCV):

    def __init__(self, *args, **kwargs):
        super(Extended, self).__init__(*args, **kwargs)

    def test(self):
        print('Extended')


x = [[1,0],[2,0],[3,0],[4,0], [30, 1]]
y = [2,4,6,8, 60]
model = Extended(alphas = [float(a)/1000.0 for a in range(1, 10000)])
model.fit(x,y)
print(model.predict([[5,1]]))
model = Extended(alphas = [float(a)/1000.0 for a in range(1, 10000)])
print(model.test())