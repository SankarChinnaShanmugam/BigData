import numpy as np


#region Exercise 1: Replace odd numbers with -1 in an array
print("Exercise 1: Replace odd numbers with -1 in an array")
arr = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
print("Input is:")
print(arr)
print("Output is:")
print(np.where(arr % 2 == 1, -1, arr))
#endregion

print("\n")

#region Exercise 2: Reshape an Array
print("Exercise 2: Reshape an Array")
arr = np.arange(10)
print("Input is:")
print(arr)
print("Output is:")
print(np.resize(arr, 10).reshape(2, 5))
#endregion

print("\n")

#region Exercise 3: Generate custom sequence
print("Exercise 3: Generate custom sequence")
arr = np.array([1, 2, 3])
print("Input is:")
print(arr)
print("Output is:")
print(np.append(np.repeat(arr, 3), np.tile(arr, (3, 1))))
#endregion

print("\n")

#region Exercise 4: Get the common elements of two array
print("Exercise 4: Get the common elements of two array")
a = np.array([1, 2, 3, 2, 3, 4, 3, 4, 5, 6])
b = np.array([7, 2, 10, 2, 7, 4, 9, 4, 9, 8])
print("Inputs are:")
print(a, b)
print("Output is:")
print(np.intersect1d(a, b))
#endregion

print("\n")

#region Exercise 5: Get the position or indices where elements of two array match
print("Exercise 5: Get the position or indices where elements of two array match")
a = np.array([1, 2, 3, 2, 3, 4, 3, 4, 5, 6])
b = np.array([7, 2, 10, 2, 7, 4, 9, 4, 9, 8])
print("Inputs are:")
print(a, b)
print("Output is:")
print(np.where(np.in1d(a, b))[0])
#endregion

print("\n")

#region Exercise 6: Create 2D with random float between 5 and 10 , 5*3 array
print("Exercise 6: Create 2D with random float between 5 and 10 , 5*3 array")
print("Output is:")
print(np.random.uniform(5, 10, (5, 3)))
#endregion

print("\n")

#region Exercise 7: Limit the number of items in print statement
print("Exercise 7: Limit the number of items in print statement")
print("Input is:")
print(np.arange(15))
np.set_printoptions(threshold=0)
print("Output is:")
print(np.arange(15))
#endregion

print("\n")

#region Exercise 8: Precession and Suppress
print("Exercise 8:  Precession and Suppress")
np.random.seed(100)
rand_arr = np.random.random([3, 3])/1e3
print("Input is:")
print(rand_arr)
np.set_printoptions(precision=6, suppress=True)
print("Output is:")
print(rand_arr)
#endregion

print("\n")

#region Exercise 9: Swap two columns in 2d array
print("Exercise 9: Swap two columns in 2d array")
arr = np.arange(9).reshape(3, 3)
print("Input is:")
print(arr)
arr[:, [0, 1]] = arr[:, [1, 0]]
print("Output is:")
print(arr)
#endregion

print("\n")

#region Exercise 10: Swap two rows in 2d array
print("Exercise 10: Swap two rows in 2d array")
arr = np.arange(9).reshape(3, 3)
print("Input is:")
print(arr)
arr[[0, 1], :] = arr[[1, 0], :]
print("Output is:")
print(arr)
#endregion
